<?php

namespace GroceryCrud\Core\GroceryCrud;


interface GroceryCrudInterface
{
    public function render();
}